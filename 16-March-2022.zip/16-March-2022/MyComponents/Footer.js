import React from 'react'

const Footer = () => {
    let footerStyle = {
        position: "fixed",
        bottom: "1px",
        width: "100%",
        marginTop: "3px"
    }
  return (
    <footer className="bg-dark text-light" style={footerStyle}>
        <p className="text-center py-3">
            Copyright &copy; MyTodoslist.com
        </p>
    </footer>
  )
}

export default Footer
