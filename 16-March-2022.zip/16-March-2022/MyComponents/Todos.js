import React from 'react'
import Todo from "./Todo";

const Todos = (props) => {
  return (
    <div className="container">
        <h3 className="my-3">TODO LIST</h3>
        {props.todo.length === 0 ? "No todos to display" : props.todo.map((todo) => { return <Todo todo={todo} key={todo.srno} onDelete={props.onDelete}/> })
        }
    </div>
  )
}

export default Todos
