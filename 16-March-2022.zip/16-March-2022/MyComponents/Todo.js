import React from 'react'

const Todo = ({todo , onDelete}) => {
    let myStyle1 = {
        border: "0 none",
        borderTop: "2px dashed green",
        background: "none",
        height:"10",
        padding: "5px"
    }
  return (
    <div> 
      <h4>{todo.title}</h4>
      <p>{todo.description}</p>
      <button type="button" className="btn btn-sm btn-warning" onClick={() => {onDelete(todo)}}>Delete</button>
      <hr style={myStyle1}></hr>
    </div>
  )
}

export default Todo
