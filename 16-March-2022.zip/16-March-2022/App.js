import logo from './logo.svg';
import './App.css';
import Header from './MyComponents/Header';
import Footer from "./MyComponents/Footer";
import Todos from "./MyComponents/Todos";
import AddTodo from "./MyComponents/AddTodo";
import About from "./MyComponents/About";
import React, { useState, useEffect } from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Routes
} from "react-router-dom";


function App() {
  let initTodo;
  if(localStorage.getItem("todos")===null){
    initTodo = [];
  }else{
    initTodo = JSON.parse(localStorage.getItem("todos"));
  }
  const onDelete = (todo) =>{
    console.log("I am on delete of todo : ",todo);
    //This will not work in react
    //let index = todos.indexOf(todo);
    //todos..splice(index,1);

    setTodos(todos.filter((e) => {
      return e !== todo;
    }));

  }
  const AddTodos = (title,desc) => {
    console.log("I am adding this todo : ",title);
    let srno;
    if(todos.length == 0 ){
      srno = 0;
    }else{
      srno = parseInt(todos[todos.length-1].srno) + 1;
    }
    const myTodo = {
      srno : srno,
      title : title,
      description : desc
    }
    setTodos([...todos,myTodo]);
    console.log(myTodo);
    alert("Successfully added your TODO.");

    
  }

  const [todos, setTodos] = useState(initTodo);
  useEffect(() =>{
    localStorage.setItem("todos",JSON.stringify(todos));
  },[todos]);
  //   [
  //   {
  //     srno : "1",
  //     title : "Go to the market",
  //     description : "You need to go tp the market to get this job done"
  //   },
  //   {
  //     srno : "2",
  //     title : "Take fruits from garden",
  //     description : "get the friuts from the garden"
  //   },
  //   {
  //     srno : "3",
  //     title : "make the cake",
  //     description : "birthday is coming so make a cake"
  //   },
  //   {
  //     srno : "4",
  //     title : "buy a book",
  //     description : "exams are coming buy a book of chemistry"
  //   },

  // ]);
  return (
    <>
      <Router>
        <Header title="MyTodosList" searchBar={true}/>
        <Routes>
          <Route exact path="/" 
          element={
            <>
              {/* render={()=>{
                  return(
                    <> */}
                      <Todos todo={todos} onDelete={onDelete}/>
                    {/* </>
                  )
                }} */}
            </>
          }/>

            <Route exact path="/about" element={<About />}/>
            <Route exact path="/addtodo" element={<AddTodo AddTodos={AddTodos}/>}/>
        </Routes>        
        <Footer/>
      </Router>
    </>
  );
}

export default App;
